module.exports = function (socket) {
  
};
